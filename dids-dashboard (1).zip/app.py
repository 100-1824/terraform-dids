from flask import Flask, render_template
import random

app = Flask(__name__)

@app.route('/')
def dashboard():
    traffic_data = [random.randint(100, 500) for _ in range(7)]
    attack_data = [random.randint(0, 50) for _ in range(7)]
    labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    return render_template('dashboard.html', traffic_data=traffic_data, attack_data=attack_data, labels=labels)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
