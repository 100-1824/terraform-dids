from flask import Flask, request
import json

app = Flask(__name__)

@app.route('/ingest', methods=['POST'])
def ingest():
    data = request.json
    print(f"Received log: {json.dumps(data)}")
    return {"status": "log received"}, 200

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)