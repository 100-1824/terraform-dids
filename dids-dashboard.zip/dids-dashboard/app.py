
from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

@app.route('/')
def dashboard():
    return render_template('index.html')

@app.route('/api/traffic')
def get_traffic():
    return jsonify([
        {"source": "10.0.0.5", "destination": "8.8.8.8", "protocol": "TCP"},
        {"source": "10.0.0.8", "destination": "192.168.1.1", "protocol": "UDP"}
    ])

@app.route('/api/anomalies')
def get_anomalies():
    return jsonify([
        {"timestamp": "2025-05-18T01:23:45", "type": "DDoS", "confidence": random.uniform(80, 99)},
        {"timestamp": "2025-05-18T01:24:12", "type": "Data Exfiltration", "confidence": random.uniform(75, 98)}
    ])

@app.route('/api/signatures')
def get_signatures():
    return jsonify([
        {"timestamp": "2025-05-18T01:20:00", "rule": "ET MALWARE Possible Malware Payload", "matched": True},
        {"timestamp": "2025-05-18T01:22:17", "rule": "ET TROJAN Suspicious Traffic", "matched": False}
    ])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
